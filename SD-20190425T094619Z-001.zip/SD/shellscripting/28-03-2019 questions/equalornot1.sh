echo "enter two numbers"
read a b
if [ $a -eq $b ]
then
echo "The numbers are equal"
elif [ $a -gt $b ]
then 
echo "number $a is greater $b is smaller"
else
echo "number $b is greater $a is smaller"
fi


 

