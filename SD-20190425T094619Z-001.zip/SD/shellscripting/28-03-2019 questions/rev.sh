echo "enter a number"
read n
for (( i=n; i>=1; i-- ))
do
echo  $i
done
